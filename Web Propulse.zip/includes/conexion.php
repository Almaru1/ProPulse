<?php
// ============================================================
// ProPulse - Connexió MySQL amb mode demo automàtic
// Si MySQL no connecta, l'aplicació NO es trenca: continua amb dades demo.
// ============================================================

mysqli_report(MYSQLI_REPORT_OFF);

$host = 'localhost';
$base_datos = 'propulse';
$credenciales = [
    ['root', ''],
    ['root', 'root'],
];

$conn = null;
$db_ok = false;
$db_error = '';

foreach ($credenciales as $c) {
    $u = $c[0];
    $p = $c[1];
    $tmp = @new mysqli($host, $u, $p, $base_datos);
    if (!$tmp->connect_error) {
        $conn = $tmp;
        $conn->set_charset('utf8mb4');
        $db_ok = true;
        break;
    }
    $db_error .= "Intent amb usuari '$u' i contrasenya " . ($p === '' ? 'buida' : 'amb valor') . ': ' . $tmp->connect_error . " | ";
}

// Dades demo per garantir que el projecte funciona encara que MySQL no estigui configurat
$DEMO_USERS = [
    'director@propulse.com' => ['id'=>1, 'nombre'=>'Carlos Martínez', 'email'=>'director@propulse.com', 'rol'=>'director', 'password'=>'propulse123', 'foto'=>'default.png'],
    'entrenador@propulse.com' => ['id'=>2, 'nombre'=>'Ana García', 'email'=>'entrenador@propulse.com', 'rol'=>'entrenador', 'password'=>'propulse123', 'foto'=>'default.png'],
    'jugador1@propulse.com' => ['id'=>3, 'nombre'=>'Marc López', 'email'=>'jugador1@propulse.com', 'rol'=>'jugador', 'password'=>'propulse123', 'foto'=>'default.png'],
];

function demo_jugadors() {
    return [
        ['id'=>3,'nombre'=>'Marc López','posicion'=>'Davanter','media_fc'=>142.4,'media_vel'=>18.7,'media_fatiga'=>41.2,'total_dist'=>4200,'num_entrenamientos'=>3],
        ['id'=>4,'nombre'=>'Pau Puig','posicion'=>'Centrecampista','media_fc'=>136.8,'media_vel'=>16.9,'media_fatiga'=>38.5,'total_dist'=>3900,'num_entrenamientos'=>3],
        ['id'=>5,'nombre'=>'Jordi Sánchez','posicion'=>'Defensa','media_fc'=>131.6,'media_vel'=>15.8,'media_fatiga'=>35.1,'total_dist'=>3600,'num_entrenamientos'=>2],
    ];
}

function demo_stats($jugador_id = 3) {
    return [
        'error'=>false,
        'labels'=>['Resistència #1','Velocitat #2','Tàctica #3','Força #4'],
        'fc'=>[138,145,141,149],
        'velocidad'=>[16.2,18.9,17.4,19.1],
        'fatiga'=>[32,44,39,51],
        'distancia'=>[980,1200,1100,1300],
        'medias'=>['media_fc'=>143.3,'media_vel'=>17.9,'media_fatiga'=>41.5,'total_dist'=>4580,'total_calorias'=>780]
    ];
}

function demo_resum_general() {
    return [
        'error'=>false,
        'labels'=>['Resistència','Velocitat','Tàctica','Força'],
        'fc'=>[136,142,139,147],
        'velocidad'=>[15.8,18.2,16.7,17.9],
        'fatiga'=>[35,42,38,49],
        'distancia'=>[3500,4100,3900,4300],
        'totales'=>['total_fc'=>141.0,'total_vel'=>17.2,'total_fatiga'=>41.0,'total_dist'=>3950]
    ];
}

function demo_entrenaments() {
    return [
        ['id'=>1,'nombre'=>'Resistència cardiovascular','descripcion'=>'Sessió de fons','estado'=>'finalizado','fecha_inicio'=>'2026-05-01 18:00:00','fecha_fin'=>'2026-05-01 19:15:00','entrenador'=>'Ana García','num_jugadores'=>3,'asistio'=>1],
        ['id'=>2,'nombre'=>'Velocitat i esprints','descripcion'=>'Treball d’acceleració','estado'=>'activo','fecha_inicio'=>'2026-05-06 18:00:00','fecha_fin'=>null,'entrenador'=>'Ana García','num_jugadores'=>3,'asistio'=>1],
        ['id'=>3,'nombre'=>'Tàctica defensiva','descripcion'=>'Posicionament','estado'=>'pendiente','fecha_inicio'=>null,'fecha_fin'=>null,'entrenador'=>'Ana García','num_jugadores'=>2,'asistio'=>0],
    ];
}
?>
