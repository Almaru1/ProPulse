<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'includes/conexion.php';
echo '<h1>ProPulse - prova de connexió</h1>';
if ($db_ok) {
    echo '<p style="color:green">✅ Connexió MySQL correcta amb la base de dades propulse.</p>';
} else {
    echo '<p style="color:orange">⚠️ MySQL no connecta, però el projecte funciona en mode demo.</p>';
    echo '<pre>'.htmlspecialchars($db_error).'</pre>';
}
echo '<p><a href="login.html">Anar al login</a></p>';
?>
