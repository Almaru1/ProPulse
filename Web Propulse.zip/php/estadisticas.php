<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once '../includes/conexion.php';
function verificarSesion(){ if(!isset($_SESSION['usuario_id'])){ echo json_encode(['error'=>true,'mensaje'=>'No autoritzat.'], JSON_UNESCAPED_UNICODE); exit; }}
$accion=$_GET['accion']??'resumen_general';
verificarSesion();
if(!$db_ok){
    if($accion==='resumen_general'){ echo json_encode(demo_resum_general(), JSON_UNESCAPED_UNICODE); exit; }
    if($accion==='jugador'){ echo json_encode(demo_stats((int)($_GET['jugador_id']??$_SESSION['usuario_id'])), JSON_UNESCAPED_UNICODE); exit; }
    if($accion==='todos_jugadores'){ echo json_encode(['error'=>false,'datos'=>demo_jugadors()], JSON_UNESCAPED_UNICODE); exit; }
}
if($accion==='resumen_general'){
    $sql="SELECT e.nombre AS entrenamiento, ROUND(AVG(db.frecuencia_cardiaca),1) AS media_fc, ROUND(AVG(db.velocidad),2) AS media_velocidad, ROUND(AVG(db.fatiga),1) AS media_fatiga, ROUND(AVG(db.distancia),0) AS media_distancia FROM datos_biometricos db JOIN entrenamientos e ON db.entrenamiento_id=e.id GROUP BY e.id,e.nombre ORDER BY e.fecha_creacion";
    $res=$conn->query($sql); $labels=[];$fc=[];$vel=[];$fat=[];$dist=[];
    if($res) while($f=$res->fetch_assoc()){ $labels[]=$f['entrenamiento']; $fc[]=(float)$f['media_fc']; $vel[]=(float)$f['media_velocidad']; $fat[]=(float)$f['media_fatiga']; $dist[]=(float)$f['media_distancia']; }
    $res2=$conn->query('SELECT ROUND(AVG(frecuencia_cardiaca),1) AS total_fc, ROUND(AVG(velocidad),2) AS total_vel, ROUND(AVG(fatiga),1) AS total_fatiga, ROUND(AVG(distancia),0) AS total_dist FROM datos_biometricos');
    $tot=$res2?$res2->fetch_assoc():['total_fc'=>0,'total_vel'=>0,'total_fatiga'=>0,'total_dist'=>0];
    echo json_encode(['error'=>false,'labels'=>$labels,'fc'=>$fc,'velocidad'=>$vel,'fatiga'=>$fat,'distancia'=>$dist,'totales'=>$tot], JSON_UNESCAPED_UNICODE); exit;
}
if($accion==='jugador'){
    $jugador_id=$_SESSION['usuario_rol']==='jugador'?$_SESSION['usuario_id']:(int)($_GET['jugador_id']??$_SESSION['usuario_id']);
    $stmt=$conn->prepare('SELECT e.nombre AS entrenamiento, db.frecuencia_cardiaca AS fc, db.velocidad, db.fatiga, db.distancia FROM datos_biometricos db JOIN entrenamientos e ON db.entrenamiento_id=e.id WHERE db.jugador_id=? ORDER BY db.timestamp_dato');
    $stmt->bind_param('i',$jugador_id); $stmt->execute(); $res=$stmt->get_result(); $labels=[];$fc=[];$vel=[];$fat=[];$dist=[];$i=1;
    while($f=$res->fetch_assoc()){ $labels[]=$f['entrenamiento'].' #'.$i++; $fc[]=(int)$f['fc']; $vel[]=(float)$f['velocidad']; $fat[]=(int)$f['fatiga']; $dist[]=(float)$f['distancia']; }
    $stmt2=$conn->prepare('SELECT ROUND(AVG(frecuencia_cardiaca),1) AS media_fc, ROUND(AVG(velocidad),2) AS media_vel, ROUND(AVG(fatiga),1) AS media_fatiga, ROUND(SUM(distancia),0) AS total_dist FROM datos_biometricos WHERE jugador_id=?');
    $stmt2->bind_param('i',$jugador_id); $stmt2->execute(); $med=$stmt2->get_result()->fetch_assoc();
    echo json_encode(['error'=>false,'labels'=>$labels,'fc'=>$fc,'velocidad'=>$vel,'fatiga'=>$fat,'distancia'=>$dist,'medias'=>$med], JSON_UNESCAPED_UNICODE); exit;
}
if($accion==='todos_jugadores'){
    $sql="SELECT u.id,u.nombre,u.posicion,ROUND(AVG(db.frecuencia_cardiaca),1) AS media_fc,ROUND(AVG(db.velocidad),2) AS media_vel,ROUND(AVG(db.fatiga),1) AS media_fatiga,ROUND(SUM(db.distancia),0) AS total_dist,COUNT(DISTINCT db.entrenamiento_id) AS num_entrenamientos FROM usuarios u LEFT JOIN datos_biometricos db ON u.id=db.jugador_id JOIN roles r ON u.rol_id=r.id WHERE r.nombre='jugador' GROUP BY u.id,u.nombre,u.posicion ORDER BY u.nombre";
    $res=$conn->query($sql); $jug=[]; if($res) while($f=$res->fetch_assoc())$jug[]=$f; echo json_encode(['error'=>false,'datos'=>$jug], JSON_UNESCAPED_UNICODE); exit;
}
echo json_encode(['error'=>true,'mensaje'=>'Acció no vàlida.'], JSON_UNESCAPED_UNICODE);
?>
