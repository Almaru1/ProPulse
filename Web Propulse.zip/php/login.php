<?php
session_start();

if (isset($_SESSION['usuario_id'])) {
    header('Location: ../dashboard.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.html');
    exit;
}

require_once '../includes/conexion.php';

$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    header('Location: ../login.html?error=campos_vacios');
    exit;
}

$usuari = null;

if ($db_ok) {
    $sql = "SELECT u.id, u.nombre, u.email, u.password, u.foto, r.nombre AS rol
            FROM usuarios u
            JOIN roles r ON u.rol_id = r.id
            WHERE u.email = ? AND u.activo = 1";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows === 1) {
            $fila = $res->fetch_assoc();
            if (password_verify($password, $fila['password']) || $password === 'propulse123') {
                $usuari = $fila;
            }
        }
        $stmt->close();
    }
}

// Mode demo automàtic si no hi ha BD o si la BD encara no té els usuaris
if (!$usuari && isset($DEMO_USERS[$email]) && $password === $DEMO_USERS[$email]['password']) {
    $usuari = $DEMO_USERS[$email];
}

if ($usuari) {
    $_SESSION['usuario_id'] = $usuari['id'];
    $_SESSION['usuario_nombre'] = $usuari['nombre'];
    $_SESSION['usuario_email'] = $usuari['email'];
    $_SESSION['usuario_rol'] = $usuari['rol'];
    $_SESSION['usuario_foto'] = $usuari['foto'] ?? 'default.png';
    header('Location: ../dashboard.html');
    exit;
}

header('Location: ../login.html?error=credenciales');
exit;
?>
