<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once '../includes/conexion.php';
function verificarSesion(){ if(!isset($_SESSION['usuario_id'])){ echo json_encode(['error'=>true,'mensaje'=>'No autoritzat.'], JSON_UNESCAPED_UNICODE); exit; }}
function verificarRol($roles){ if(!in_array($_SESSION['usuario_rol'],$roles)){ echo json_encode(['error'=>true,'mensaje'=>'Sense permisos.'], JSON_UNESCAPED_UNICODE); exit; }}
$accion=$_GET['accion']??'listar'; verificarSesion();
if(!$db_ok){
    if($accion==='listar'){ echo json_encode(['error'=>false,'datos'=>demo_entrenaments()], JSON_UNESCAPED_UNICODE); exit; }
    if($accion==='crear'){ verificarRol(['entrenador','director']); echo json_encode(['error'=>false,'mensaje'=>'Entrenament creat en mode demo.','id'=>rand(10,99)], JSON_UNESCAPED_UNICODE); exit; }
    if($accion==='cambiar_estado'){ verificarRol(['entrenador','director']); echo json_encode(['error'=>false,'mensaje'=>'Estat actualitzat en mode demo.'], JSON_UNESCAPED_UNICODE); exit; }
}
if($accion==='listar'){
    if($_SESSION['usuario_rol']==='jugador'){
        $stmt=$conn->prepare('SELECT e.id,e.nombre,e.descripcion,e.estado,e.fecha_inicio,e.fecha_fin,u.nombre AS entrenador,se.asistio,se.puntuacion,se.notas FROM entrenamientos e JOIN sesiones_entrenamiento se ON e.id=se.entrenamiento_id JOIN usuarios u ON e.entrenador_id=u.id WHERE se.jugador_id=? ORDER BY e.fecha_creacion DESC');
        $id=$_SESSION['usuario_id']; $stmt->bind_param('i',$id);
    } else {
        $stmt=$conn->prepare('SELECT e.id,e.nombre,e.descripcion,e.estado,e.fecha_inicio,e.fecha_fin,u.nombre AS entrenador,COUNT(se.jugador_id) AS num_jugadores FROM entrenamientos e JOIN usuarios u ON e.entrenador_id=u.id LEFT JOIN sesiones_entrenamiento se ON e.id=se.entrenamiento_id GROUP BY e.id ORDER BY e.fecha_creacion DESC');
    }
    $stmt->execute(); $res=$stmt->get_result(); $arr=[]; while($f=$res->fetch_assoc())$arr[]=$f; echo json_encode(['error'=>false,'datos'=>$arr], JSON_UNESCAPED_UNICODE); exit;
}
if($accion==='crear' && $_SERVER['REQUEST_METHOD']==='POST'){
    verificarRol(['entrenador','director']); $nombre=trim($_POST['nombre']??''); $desc=trim($_POST['descripcion']??''); if($nombre===''){echo json_encode(['error'=>true,'mensaje'=>'El nom és obligatori.'], JSON_UNESCAPED_UNICODE); exit;}
    $stmt=$conn->prepare("INSERT INTO entrenamientos (nombre,descripcion,entrenador_id,estado) VALUES (?,?,?,'pendiente')"); $eid=$_SESSION['usuario_id']; $stmt->bind_param('ssi',$nombre,$desc,$eid);
    echo json_encode($stmt->execute()?['error'=>false,'mensaje'=>'Entrenament creat.','id'=>$conn->insert_id]:['error'=>true,'mensaje'=>'Error en crear l’entrenament.'], JSON_UNESCAPED_UNICODE); exit;
}
if($accion==='cambiar_estado' && $_SERVER['REQUEST_METHOD']==='POST'){
    verificarRol(['entrenador','director']); $id=(int)($_POST['id']??0); $estado=trim($_POST['estado']??''); if(!in_array($estado,['activo','pausado','finalizado'])){echo json_encode(['error'=>true,'mensaje'=>'Estat no vàlid.'], JSON_UNESCAPED_UNICODE); exit;}
    $stmt=$conn->prepare('UPDATE entrenamientos SET estado=? WHERE id=?'); $stmt->bind_param('si',$estado,$id); echo json_encode($stmt->execute()?['error'=>false,'mensaje'=>'Estat actualitzat.']:['error'=>true,'mensaje'=>'Error en actualitzar.'], JSON_UNESCAPED_UNICODE); exit;
}
echo json_encode(['error'=>true,'mensaje'=>'Acció no vàlida.'], JSON_UNESCAPED_UNICODE);
?>
