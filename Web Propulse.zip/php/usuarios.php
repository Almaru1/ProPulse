<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once '../includes/conexion.php';

function verificarSesion() {
    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['error'=>true,'mensaje'=>'No autoritzat. Inicia sessió.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
function verificarRol($roles) {
    if (!in_array($_SESSION['usuario_rol'], $roles)) {
        echo json_encode(['error'=>true,'mensaje'=>'Sense permisos per a aquesta acció.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

$accion = $_GET['accion'] ?? 'listar';

if ($accion === 'sesion_info') {
    verificarSesion();
    echo json_encode(['error'=>false,'id'=>$_SESSION['usuario_id'],'nombre'=>$_SESSION['usuario_nombre'],'email'=>$_SESSION['usuario_email'],'rol'=>$_SESSION['usuario_rol'],'foto'=>$_SESSION['usuario_foto']], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($accion === 'listar') {
    verificarSesion(); verificarRol(['director','entrenador']);
    if (!$db_ok) {
        echo json_encode(['error'=>false,'datos'=>demo_jugadors()], JSON_UNESCAPED_UNICODE); exit;
    }
    $sql = "SELECT u.id, u.nombre, u.email, u.posicion, u.edad, u.altura, u.peso, u.foto, u.activo, r.nombre AS rol FROM usuarios u JOIN roles r ON u.rol_id = r.id ORDER BY r.id, u.nombre";
    $res = $conn->query($sql); $usuarios=[];
    if ($res) while($f=$res->fetch_assoc()) $usuarios[]=$f;
    echo json_encode(['error'=>false,'datos'=>$usuarios], JSON_UNESCAPED_UNICODE); exit;
}

if ($accion === 'crear' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verificarSesion(); verificarRol(['director']);
    if (!$db_ok) { echo json_encode(['error'=>false,'mensaje'=>'Usuari creat en mode demo.','id'=>rand(10,99)], JSON_UNESCAPED_UNICODE); exit; }
    $nombre=trim($_POST['nombre']??''); $email=trim($_POST['email']??''); $password=trim($_POST['password']??'');
    $rol_id=(int)($_POST['rol_id']??3); $posicion=trim($_POST['posicion']??''); $edad=(int)($_POST['edad']??0); $altura=(float)($_POST['altura']??0); $peso=(float)($_POST['peso']??0);
    if ($nombre==='' || $email==='' || $password==='') { echo json_encode(['error'=>true,'mensaje'=>'El nom, el correu i la contrasenya són obligatoris.'], JSON_UNESCAPED_UNICODE); exit; }
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $stmt=$conn->prepare('INSERT INTO usuarios (nombre,email,password,rol_id,posicion,edad,altura,peso) VALUES (?,?,?,?,?,?,?,?)');
    $stmt->bind_param('sssissdd',$nombre,$email,$hash,$rol_id,$posicion,$edad,$altura,$peso);
    echo json_encode($stmt->execute()?['error'=>false,'mensaje'=>'Usuari creat correctament.','id'=>$conn->insert_id]:['error'=>true,'mensaje'=>'Error en crear l’usuari.'], JSON_UNESCAPED_UNICODE); exit;
}

echo json_encode(['error'=>true,'mensaje'=>'Acció no vàlida.'], JSON_UNESCAPED_UNICODE);
?>
