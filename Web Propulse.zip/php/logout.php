<?php
// ============================================================
// ProPulse - php/logout.php
// Què fa? Cierra la sesión del usuario
// Com funciona? Destruye todos los datos de sesión
// Què rep? Nada (solo la llamada GET/POST)
// Què retorna? Redirige a la página de login
// ============================================================

// Iniciar sesión para poder destruirla
session_start();

// Eliminar todas las variables de sesión
$_SESSION = [];

// Destruir la sesión completamente
session_destroy();

// Redirigir a la página de inicio/login
header("Location: ../login.html?mensaje=sesion_cerrada");
exit;
?>
