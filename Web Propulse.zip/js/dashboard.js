// ============================================================
// ProPulse - js/dashboard.js
// ¿Qué hace? Controla TODA la lógica del dashboard
// ¿Cómo funciona? Hace llamadas fetch() a los archivos PHP
//                 y actualiza el HTML con los datos recibidos
// ============================================================

// ---- Variables globales ----
let usuarioActual = null;      // Datos del usuario logueado
let todosJugadors = [];       // Cache de la lista de jugadores
let todosEntrenaments = [];  // Cache de los entrenamientos
let graficasInstancias = {};   // Para destruir gráficas antes de recrearlas

// ============================================================
// INICIO: Se ejecuta cuando carga la página
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    // 1. Obtener datos de la sesión actual
    cargarSesion();
});

// ============================================================
// FUNCIÓN: cargarSesion()
// Pide al PHP los datos del usuario logueado
// Si no hay sesión, redirige al login
// ============================================================
function cargarSesion() {
    fetch('php/usuarios.php?accion=sesion_info')
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                // No hay sesión → ir al login
                window.location.href = 'login.html';
                return;
            }

            // Guardar datos del usuario
            usuarioActual = data;

            // Mostrar nombre y rol en el sidebar
            document.getElementById('sidebar-nombre').textContent = data.nombre;
            document.getElementById('sidebar-rol').textContent = data.rol;

            // Mostrar inicial del nombre en el avatar
            const inicial = data.nombre.charAt(0).toUpperCase();
            document.getElementById('sidebar-avatar').textContent = inicial;

            // Construir menú según el rol
            construirMenu(data.rol);

            // Cargar la sección inicial (dashboard)
            cargarTauler();
        })
        .catch(() => {
            // Error de red → redirigir
            window.location.href = 'login.html';
        });
}

// ============================================================
// FUNCIÓN: construirMenu(rol)
// Genera los links del sidebar según el rol del usuario
// ============================================================
function construirMenu(rol) {
    const nav = document.getElementById('sidebar-nav');

    // Menú común para todos los roles
    let html = `
        <div class="nav-seccion">Principal</div>
        <a class="nav-item activo" onclick="mostrarSeccion('dashboard')">
            <span class="icono">🏠</span> Tauler
        </a>
    `;

    // Menú para director y entrenador
    if (rol === 'director' || rol === 'entrenador') {
        html += `
            <div class="nav-seccion">Gestió</div>
            <a class="nav-item" onclick="mostrarSeccion('jugadores')">
                <span class="icono">👥</span> Jugadors
            </a>
            <a class="nav-item" onclick="mostrarSeccion('entrenamientos')">
                <span class="icono">🏋️</span> Entrenaments
            </a>
        `;
    }

    // Menú exclusivo del director
    if (rol === 'director') {
        html += `
            <div class="nav-seccion">Administració</div>
            <a class="nav-item" onclick="mostrarSeccion('crear-usuario')">
                <span class="icono">➕</span> Crear Usuari
            </a>
        `;
    }

    // Menú exclusivo del jugador
    if (rol === 'jugador') {
        html += `
            <div class="nav-seccion">El meu perfil</div>
            <a class="nav-item" onclick="mostrarSeccion('mis-stats')">
                <span class="icono">📊</span> Les meves estadístiques
            </a>
            <a class="nav-item" onclick="mostrarSeccion('entrenamientos')">
                <span class="icono">🏋️</span> Mis Entrenaments
            </a>
        `;
    }

    nav.innerHTML = html;
}

// ============================================================
// FUNCIÓN: mostrarSeccion(nombre)
// Oculta todas las secciones y muestra la solicitada
// ============================================================
function mostrarSeccion(nombre) {
    // Ocultar todas las secciones
    document.querySelectorAll('.seccion-pagina').forEach(s => s.style.display = 'none');

    // Mostrar la sección pedida
    const seccion = document.getElementById('seccion-' + nombre);
    if (seccion) {
        seccion.style.display = 'block';
        seccion.classList.add('fade-in');
    }

    // Marcar el item activo en el menú
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('activo'));
    event && event.target && event.target.closest('.nav-item') &&
        event.target.closest('.nav-item').classList.add('activo');

    // Cargar datos de la sección si es necesario
    if (nombre === 'jugadores') cargarJugadors();
    if (nombre === 'entrenamientos') cargarEntrenaments();
    if (nombre === 'mis-stats') cargarMisEstadisticas();

    // Cerrar sidebar en móvil
    document.getElementById('sidebar').classList.remove('abierto');
}

// ============================================================
// FUNCIÓN: cargarTauler()
// Carga las estadísticas y gráficas del dashboard
// ============================================================
function cargarTauler() {
    // Personalizar el título según el rol
    const titulos = {
        'director': ['Tauler del director', 'Visió global de l’equip'],
        'entrenador': ['Tauler de l’entrenador', 'Gestió de sesiones y jugadores'],
        'jugador': ['Mi Tauler', 'El teu rendiment esportiu']
    };

    const [titulo, subtitulo] = titulos[usuarioActual.rol] || ['Tauler', ''];
    document.getElementById('dashboard-titulo').textContent = titulo;
    document.getElementById('dashboard-subtitulo').textContent = subtitulo;

    // Si es jugador → cargar sus propios datos
    if (usuarioActual.rol === 'jugador') {
        fetch('php/estadisticas.php?accion=jugador')
            .then(res => res.json())
            .then(data => {
                if (!data.error) {
                    // Actualizar KPIs
                    actualizarKPI('kpi-fc', data.medias.media_fc, 'bpm');
                    actualizarKPI('kpi-vel', data.medias.media_vel, 'km/h');
                    actualizarKPI('kpi-fatiga', data.medias.media_fatiga, '%');
                    actualizarKPI('kpi-dist', data.medias.total_dist, 'm');

                    // Crear gráficas
                    crearGrafica('graficaFC', 'line', data.labels, data.fc, '💓 Freqüència cardíaca', '#ff6b6b');
                    crearGrafica('graficaVelocitat', 'line', data.labels, data.velocidad, '⚡ Velocitat', '#0066ff');
                    crearGrafica('graficaFatiga', 'bar', data.labels, data.fatiga, '🔋 Fatiga', '#ff9f43');
                    crearGrafica('graficaDistància', 'bar', data.labels, data.distancia, '📏 Distància', '#00e676');
                }
            });
    } else {
        // Director o entrenador → datos generales del equipo
        fetch('php/estadisticas.php?accion=resumen_general')
            .then(res => res.json())
            .then(data => {
                if (!data.error) {
                    // Actualizar KPIs con las medias globales
                    actualizarKPI('kpi-fc', data.totales.total_fc, 'bpm');
                    actualizarKPI('kpi-vel', data.totales.total_vel, 'km/h');
                    actualizarKPI('kpi-fatiga', data.totales.total_fatiga, '%');
                    actualizarKPI('kpi-dist', data.totales.total_dist, 'm');

                    // Crear gráficas del equipo
                    crearGrafica('graficaFC', 'line', data.labels, data.fc, '💓 FC mitjana de l’equip', '#ff6b6b');
                    crearGrafica('graficaVelocitat', 'line', data.labels, data.velocidad, '⚡ Velocitat Media', '#0066ff');
                    crearGrafica('graficaFatiga', 'bar', data.labels, data.fatiga, '🔋 Fatiga mitjana', '#ff9f43');
                    crearGrafica('graficaDistància', 'bar', data.labels, data.distancia, '📏 Distància Media', '#00e676');
                }
            });
    }
}

// ============================================================
// FUNCIÓN: actualizarKPI(id, valor, unidad)
// Actualiza el valor de una tarjeta KPI
// ============================================================
function actualizarKPI(id, valor, unidad) {
    const el = document.getElementById(id);
    if (el) {
        el.innerHTML = (valor || '--') + '<span class="stat-unidad">' + unidad + '</span>';
    }
}

// ============================================================
// FUNCIÓN: crearGrafica(canvasId, tipo, labels, datos, label, color)
// Crea o actualiza una gráfica de Chart.js
// ============================================================
function crearGrafica(canvasId, tipo, labels, datos, label, color) {
    // Si ya existe una gráfica en ese canvas, destruirla primero
    if (graficasInstancias[canvasId]) {
        graficasInstancias[canvasId].destroy();
    }

    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    // Configuración de Chart.js
    graficasInstancias[canvasId] = new Chart(ctx, {
        type: tipo,  // 'line' o 'bar'
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: datos,
                // Colores según el tipo de gráfica
                borderColor: color,
                backgroundColor: tipo === 'line'
                    ? color + '20'     // Relleno transparente para líneas
                    : color + '80',    // Relleno semitransparente para barras
                borderWidth: 2,
                pointBackgroundColor: color,
                pointRadius: 4,
                tension: 0.4,          // Suavizado de la línea
                fill: tipo === 'line'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#12121a',
                    borderColor: '#1e1e2e',
                    borderWidth: 1,
                    titleColor: '#fff',
                    bodyColor: '#a0a0b8'
                }
            },
            scales: {
                x: {
                    ticks: { color: '#a0a0b8', font: { size: 10 } },
                    grid: { color: '#1e1e2e' }
                },
                y: {
                    ticks: { color: '#a0a0b8', font: { size: 10 } },
                    grid: { color: '#1e1e2e' }
                }
            }
        }
    });
}

// ============================================================
// FUNCIÓN: cargarJugadors()
// Obtiene la lista de jugadores del PHP y la muestra en la tabla
// ============================================================
function cargarJugadors() {
    fetch('php/estadisticas.php?accion=todos_jugadores')
        .then(res => res.json())
        .then(data => {
            if (data.error) return;

            // Guardar en cache global para filtrar sin recargar
            todosJugadors = data.datos;
            renderizarTablaJugadors(todosJugadors);
        });
}

// ============================================================
// FUNCIÓN: renderizarTablaJugadors(jugadores)
// Genera el HTML de la tabla de jugadores
// ============================================================
function renderizarTablaJugadors(jugadores) {
    const tbody = document.getElementById('tabla-jugadores-body');

    if (jugadores.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:#4a4a6a; padding:32px">Sense resultats</td></tr>';
        return;
    }

    tbody.innerHTML = jugadores.map(j => `
        <tr>
            <td>
                <div class="jugador-avatar">${j.nombre.charAt(0)}</div>
                ${j.nombre}
            </td>
            <td>${j.posicion || '—'}</td>
            <td>—</td>
            <td>${j.media_fc ? j.media_fc + ' bpm' : '—'}</td>
            <td>${j.media_vel ? j.media_vel + ' km/h' : '—'}</td>
            <td>${j.media_fatiga ? j.media_fatiga + '%' : '—'}</td>
            <td>${j.num_entrenamientos || 0}</td>
            <td>
                <button class="btn btn-primary btn-sm" onclick="verStatsJugador(${j.id}, '${j.nombre}')">
                    📊 Veure gràfica
                </button>
            </td>
        </tr>
    `).join('');
}

// ============================================================
// FUNCIÓN: filtrarJugadors()
// Filtra la tabla por el texto del buscador
// ============================================================
function filtrarJugadors() {
    const texto = document.getElementById('buscador-jugadores').value.toLowerCase();
    const filtrados = todosJugadors.filter(j =>
        j.nombre.toLowerCase().includes(texto) ||
        (j.posicion && j.posicion.toLowerCase().includes(texto))
    );
    renderizarTablaJugadors(filtrados);
}

// Filtrar por posición
let filtroActualPosicion = 'todos';
function filtrarPor(posicion, btn) {
    filtroActualPosicion = posicion;
    document.querySelectorAll('.filtros .filtro-btn').forEach(b => b.classList.remove('activo'));
    btn.classList.add('activo');

    const filtrados = posicion === 'todos'
        ? todosJugadors
        : todosJugadors.filter(j => j.posicion && j.posicion.toLowerCase() === posicion);
    renderizarTablaJugadors(filtrados);
}

// ============================================================
// FUNCIÓN: verStatsJugador(id, nombre)
// Abre el modal con las estadísticas de un jugador concreto
// ============================================================
function verStatsJugador(id, nombre) {
    document.getElementById('modal-stats-titulo').textContent = '📊 ' + nombre;
    abrirModal('modal-stats-jugador');

    fetch('php/estadisticas.php?accion=jugador&jugador_id=' + id)
        .then(res => res.json())
        .then(data => {
            if (data.error) return;

            // Actualizar KPIs del modal
            document.getElementById('m-kpi-fc').textContent = (data.medias.media_fc || '--') + ' bpm';
            document.getElementById('m-kpi-vel').textContent = (data.medias.media_vel || '--') + ' km/h';
            document.getElementById('m-kpi-fatiga').textContent = (data.medias.media_fatiga || '--') + '%';

            // Gráfica del modal
            if (graficasInstancias['graficaModalJugador']) {
                graficasInstancias['graficaModalJugador'].destroy();
            }
            const ctx = document.getElementById('graficaModalJugador');
            graficasInstancias['graficaModalJugador'] = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [
                        {
                            label: 'FC (bpm)',
                            data: data.fc,
                            borderColor: '#ff6b6b',
                            tension: 0.4,
                            fill: false,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Fatiga (%)',
                            data: data.fatiga,
                            borderColor: '#ff9f43',
                            tension: 0.4,
                            fill: false,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Velocitat (km/h)',
                            data: data.velocidad,
                            borderColor: '#0066ff',
                            tension: 0.4,
                            fill: false,
                            yAxisID: 'y'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            labels: { color: '#a0a0b8', font: { size: 11 } }
                        },
                        tooltip: {
                            backgroundColor: '#12121a',
                            borderColor: '#1e1e2e',
                            borderWidth: 1
                        }
                    },
                    scales: {
                        x: { ticks: { color: '#a0a0b8' }, grid: { color: '#1e1e2e' } },
                        y: { ticks: { color: '#a0a0b8' }, grid: { color: '#1e1e2e' } }
                    }
                }
            });
        });
}

// ============================================================
// FUNCIÓN: cargarEntrenaments()
// Carga la tabla de entrenamientos desde el PHP
// ============================================================
function cargarEntrenaments() {
    // Mostrar botón crear y columna acciones solo a entrenadores/directores
    if (usuarioActual.rol !== 'jugador') {
        const btnCrear = document.getElementById('btn-crear-entreno');
        const thAcciones = document.getElementById('th-acciones-entreno');
        if (btnCrear) btnCrear.style.display = 'inline-flex';
        if (thAcciones) thAcciones.style.display = '';
    }

    fetch('php/entrenamientos.php?accion=listar')
        .then(res => res.json())
        .then(data => {
            if (data.error) return;
            todosEntrenaments = data.datos;
            renderizarTablaEntrenaments(todosEntrenaments);
        });
}

// ============================================================
// FUNCIÓN: renderizarTablaEntrenaments(lista)
// Genera las filas de la tabla de entrenamientos
// ============================================================
function renderizarTablaEntrenaments(lista) {
    const tbody = document.getElementById('tabla-entrenamientos-body');
    const esEntrenador = usuarioActual.rol !== 'jugador';

    if (lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#4a4a6a; padding:32px">No hi ha entrenaments</td></tr>';
        return;
    }

    tbody.innerHTML = lista.map(e => {
        // Botones de acción según el estado actual
        let botonesAccion = '';
        if (esEntrenador) {
            if (e.estado === 'pendiente') {
                botonesAccion = `<button class="btn btn-success btn-sm" onclick="cambiarEstado(${e.id}, 'activo')">▶ Iniciar</button>`;
            } else if (e.estado === 'activo') {
                botonesAccion = `
                    <button class="btn btn-warning btn-sm" onclick="cambiarEstado(${e.id}, 'pausado')">⏸ Pausar</button>
                    <button class="btn btn-danger btn-sm" onclick="cambiarEstado(${e.id}, 'finalizado')">⏹ Finalitzar</button>
                `;
            } else if (e.estado === 'pausado') {
                botonesAccion = `
                    <button class="btn btn-success btn-sm" onclick="cambiarEstado(${e.id}, 'activo')">▶ Reprendre</button>
                    <button class="btn btn-danger btn-sm" onclick="cambiarEstado(${e.id}, 'finalizado')">⏹ Finalitzar</button>
                `;
            }
        }

        // Formatear la fecha
        const fecha = e.fecha_inicio
            ? new Date(e.fecha_inicio).toLocaleDateString('es-ES')
            : '—';

        return `
            <tr>
                <td><strong>${e.nombre}</strong></td>
                <td>${e.entrenador || '—'}</td>
                <td><span class="badge badge-${e.estado}">${e.estado}</span></td>
                <td>${esEntrenador ? (e.num_jugadores || 0) : (e.asistio !== undefined ? (Number(e.asistio) === 1 ? '✅ Hi he assistit' : '❌ No hi he assistit') : '—')}</td>
                <td>${fecha}</td>
                ${esEntrenador ? `<td style="display:flex; gap:6px; flex-wrap:wrap">${botonesAccion}</td>` : ''}
            </tr>
        `;
    }).join('');
}

// Filtrar entrenamientos por estado
function filtrarEntrenaments(estado, btn) {
    document.querySelectorAll('#seccion-entrenamientos .filtros .filtro-btn')
        .forEach(b => b.classList.remove('activo'));
    btn.classList.add('activo');

    const filtrados = estado === 'todos'
        ? todosEntrenaments
        : todosEntrenaments.filter(e => e.estado === estado);
    renderizarTablaEntrenaments(filtrados);
}

// ============================================================
// FUNCIÓN: cambiarEstado(id, nuevoEstado)
// Llama al PHP para cambiar el estado de un entrenamiento
// ============================================================
function cambiarEstado(id, nuevoEstado) {
    // Usar FormData para enviar datos por POST
    const formData = new FormData();
    formData.append('id', id);
    formData.append('estado', nuevoEstado);

    fetch('php/entrenamientos.php?accion=cambiar_estado', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (!data.error) {
            // Recargar la tabla para mostrar el nuevo estado
            cargarEntrenaments();
        } else {
            alert('Error: ' + data.mensaje);
        }
    });
}

// ============================================================
// FUNCIÓN: crearEntrenamiento()
// Recoge el formulario del modal y lo envía al PHP
// ============================================================
function crearEntrenamiento() {
    const nombre = document.getElementById('e-nombre').value.trim();
    const descripcion = document.getElementById('e-descripcion').value.trim();
    const jugadores = document.getElementById('e-jugadores').value.trim();

    const alerta = document.getElementById('alerta-modal-entreno');

    if (!nombre) {
        mostrarAlerta(alerta, 'error', '⚠️ El nom és obligatori');
        return;
    }

    const formData = new FormData();
    formData.append('nombre', nombre);
    formData.append('descripcion', descripcion);
    formData.append('jugadores', jugadores);

    fetch('php/entrenamientos.php?accion=crear', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (!data.error) {
            mostrarAlerta(alerta, 'exito', '✅ Entrenament creat correctament');
            setTimeout(() => {
                cerrarModal('modal-entrenamiento');
                cargarEntrenaments();
            }, 1200);
        } else {
            mostrarAlerta(alerta, 'error', '❌ ' + data.mensaje);
        }
    });
}

// ============================================================
// FUNCIÓN: crearUsuario()
// Recoge el formulario de creación de usuario y lo envía al PHP
// ============================================================
function crearUsuario() {
    const alerta = document.getElementById('alerta-usuario');

    const formData = new FormData();
    formData.append('nombre', document.getElementById('u-nombre').value);
    formData.append('email', document.getElementById('u-email').value);
    formData.append('password', document.getElementById('u-password').value);
    formData.append('rol_id', document.getElementById('u-rol').value);
    formData.append('posicion', document.getElementById('u-posicion').value);
    formData.append('edad', document.getElementById('u-edad').value);
    formData.append('altura', document.getElementById('u-altura').value);
    formData.append('peso', document.getElementById('u-peso').value);

    fetch('php/usuarios.php?accion=crear', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (!data.error) {
            mostrarAlerta(alerta, 'exito', '✅ Usuari creat correctament. ID: ' + data.id);
            // Limpiar el formulario
            ['u-nombre','u-email','u-password','u-posicion','u-edad','u-altura','u-peso']
                .forEach(id => document.getElementById(id).value = '');
        } else {
            mostrarAlerta(alerta, 'error', '❌ ' + data.mensaje);
        }
    });
}

// ============================================================
// FUNCIÓN: cargarMisEstadisticas()
// Carga las estadísticas personales del jugador logueado
// ============================================================
function cargarMisEstadisticas() {
    fetch('php/estadisticas.php?accion=jugador')
        .then(res => res.json())
        .then(data => {
            if (data.error) return;

            // Actualizar KPIs personales
            actualizarKPI('p-kpi-fc', data.medias.media_fc, 'bpm');
            actualizarKPI('p-kpi-vel', data.medias.media_vel, 'km/h');
            actualizarKPI('p-kpi-fatiga', data.medias.media_fatiga, '%');
            actualizarKPI('p-kpi-dist', data.medias.total_dist, 'm');

            // Crear las 4 gráficas personales
            crearGrafica('graficaMiFC', 'line', data.labels, data.fc, 'Freqüència cardíaca', '#ff6b6b');
            crearGrafica('graficaMiFatiga', 'bar', data.labels, data.fatiga, 'Fatiga', '#ff9f43');
            crearGrafica('graficaMiVel', 'line', data.labels, data.velocidad, 'Velocitat', '#0066ff');
            crearGrafica('graficaMiDist', 'bar', data.labels, data.distancia, 'Distància', '#00e676');
        });
}

// ============================================================
// UTILIDADES: Modal, Alertas, Sidebar
// ============================================================

// Abrir modal
function abrirModal(id) {
    document.getElementById(id).classList.add('visible');
}

// Cerrar modal
function cerrarModal(id) {
    document.getElementById(id).classList.remove('visible');
}

// Cerrar modal si se hace clic fuera
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function (e) {
        if (e.target === this) this.classList.remove('visible');
    });
});

// Abrir modal de entrenamiento
function abrirModalEntrenamiento() {
    document.getElementById('e-nombre').value = '';
    document.getElementById('e-descripcion').value = '';
    document.getElementById('e-jugadores').value = '';
    abrirModal('modal-entrenamiento');
}

// Mostrar alerta en un contenedor
function mostrarAlerta(el, tipo, mensaje) {
    el.className = 'alerta alerta-' + tipo + ' visible';
    el.textContent = mensaje;
    // Ocultar automáticamente después de 4 segundos
    setTimeout(() => el.classList.remove('visible'), 4000);
}

// Toggle sidebar en móvil
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('abierto');
}
