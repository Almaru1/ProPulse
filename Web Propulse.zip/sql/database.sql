-- ============================================================
-- ProPulse - Instal·lació neta compatible amb phpMyAdmin
-- Importa aquest fitxer dins de la base de dades que ja has creat.
-- No conté CREATE DATABASE ni USE, per evitar l'error #1044.
-- Contrasenya dels comptes de prova: propulse123
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS sesiones_entrenamiento;
DROP TABLE IF EXISTS datos_biometricos;
DROP TABLE IF EXISTS entrenamientos;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS roles;
SET FOREIGN_KEY_CHECKS = 1;

-- -------------------------------------------------------
-- TAULA: roles
-- Emmagatzema els tipus d’usuari del sistema
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,          -- Nombre del rol: director, entrenador, jugador
    descripcion VARCHAR(200)              -- Descripción breve del rol
);

-- Inserir els 3 rols del sistema
INSERT INTO roles (nombre, descripcion) VALUES
('director', 'Director tècnic amb accés total'),
('entrenador', 'Entrenador amb gestió de sessions'),
('jugador', 'Jugador amb accés a les seves pròpies dades');

-- -------------------------------------------------------
-- TAULA: usuarios
-- Emmagatzema tots els usuaris del sistema
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,          -- Nom complet
    email VARCHAR(150) NOT NULL UNIQUE,    -- Correu únic per iniciar sessió
    password VARCHAR(255) NOT NULL,        -- Contrasenya xifrada amb password_hash()
    rol_id INT NOT NULL,                   -- FK a la tabla roles
    posicion VARCHAR(100),                 -- Posición del jugador (si aplica)
    edad INT,                              -- Edad del usuario
    altura DECIMAL(4,1),                   -- Altura en cm
    peso DECIMAL(5,2),                     -- Peso en kg
    foto VARCHAR(255) DEFAULT 'default.png', -- Foto de perfil
    activo TINYINT(1) DEFAULT 1,           -- 1=activo, 0=inactivo
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);

-- Inserir usuaris de prova (contrasenya: "propulse123" para todos)
INSERT INTO usuarios (nombre, email, password, rol_id, posicion, edad, altura, peso) VALUES
('Carlos Martínez', 'director@propulse.com', '$2y$10$8P2pMTTAcNGIwv7q.aDpZ.QSqUqkwAevU3zSaV.30qhhXLpgCrEQe', 1, NULL, 45, 178.0, 82.0),
('Ana García', 'entrenador@propulse.com', '$2y$10$8P2pMTTAcNGIwv7q.aDpZ.QSqUqkwAevU3zSaV.30qhhXLpgCrEQe', 2, NULL, 32, 165.0, 62.0),
('Marc López', 'jugador1@propulse.com', '$2y$10$8P2pMTTAcNGIwv7q.aDpZ.QSqUqkwAevU3zSaV.30qhhXLpgCrEQe', 3, 'Delantero', 22, 182.0, 76.0),
('Pau Puig', 'jugador2@propulse.com', '$2y$10$8P2pMTTAcNGIwv7q.aDpZ.QSqUqkwAevU3zSaV.30qhhXLpgCrEQe', 3, 'Centrocampista', 24, 175.0, 70.0),
('Jordi Sánchez', 'jugador3@propulse.com', '$2y$10$8P2pMTTAcNGIwv7q.aDpZ.QSqUqkwAevU3zSaV.30qhhXLpgCrEQe', 3, 'Defensa', 21, 180.0, 78.0);

-- -------------------------------------------------------
-- TAULA: entrenamientos (sessions d’entrenament)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS entrenamientos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,          -- Nom de la sessió
    descripcion TEXT,                      -- Descripció de l’entrenament
    entrenador_id INT NOT NULL,            -- Qui ha creat la sessió
    estado ENUM('pendiente','activo','pausado','finalizado') DEFAULT 'pendiente',
    fecha_inicio DATETIME,                 -- Quan ha començat
    fecha_fin DATETIME,                    -- Quan ha acabat
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entrenador_id) REFERENCES usuarios(id)
);

-- Inserir entrenaments de prova
INSERT INTO entrenamientos (nombre, descripcion, entrenador_id, estado, fecha_inicio, fecha_fin) VALUES
('Resistencia Cardiovascular', 'Trabajo de fondo y resistencia aeróbica', 2, 'finalizado', '2025-01-10 09:00:00', '2025-01-10 10:30:00'),
('Velocidad y Sprint', 'Series de velocidad corta y media', 2, 'finalizado', '2025-01-12 10:00:00', '2025-01-12 11:00:00'),
('Técnica y Táctica', 'Ejercicios de posesión y pressing', 2, 'finalizado', '2025-01-15 09:30:00', '2025-01-15 11:00:00'),
('Fuerza Explosiva', 'Trabajo de potencia muscular', 2, 'pendiente', NULL, NULL);

-- -------------------------------------------------------
-- TAULA: datos_biometricos
-- Dades que envia la polsera intel·ligent durant els entrenaments
-- En producció: aquestes dades arribarien via API de la polsera
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS datos_biometricos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jugador_id INT NOT NULL,               -- A quin jugador pertanyen
    entrenamiento_id INT NOT NULL,         -- En quin entrenament s’han registrat
    frecuencia_cardiaca INT,               -- Pulsacions per minut
    velocidad DECIMAL(5,2),                -- Velocitat en km/h
    distancia DECIMAL(6,2),               -- Distància en metres
    fatiga INT,                            -- Nivell de fatiga del 0 al 100
    calorias INT,                          -- Calories cremades
    timestamp_dato TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (jugador_id) REFERENCES usuarios(id),
    FOREIGN KEY (entrenamiento_id) REFERENCES entrenamientos(id)
);

-- Inserir dades biomètriques de prova
INSERT INTO datos_biometricos (jugador_id, entrenamiento_id, frecuencia_cardiaca, velocidad, distancia, fatiga, calorias) VALUES
-- Marc López - Entrenamiento 1
(3, 1, 142, 12.5, 4200, 45, 380),
(3, 1, 158, 14.2, 7800, 62, 720),
(3, 1, 165, 13.8, 10200, 75, 980),
-- Marc López - Entrenamiento 2
(3, 2, 155, 18.5, 2100, 55, 290),
(3, 2, 172, 22.3, 4500, 70, 520),
-- Pau Puig - Entrenamiento 1
(4, 1, 138, 11.8, 3900, 40, 350),
(4, 1, 150, 13.2, 7200, 58, 680),
(4, 1, 160, 12.9, 9800, 72, 920),
-- Jordi Sánchez - Entrenamiento 1
(5, 1, 135, 10.5, 3500, 38, 320),
(5, 1, 148, 12.0, 6800, 55, 640),
-- Jordi Sánchez - Entrenamiento 3
(5, 3, 145, 11.2, 4100, 48, 410),
(5, 3, 162, 13.5, 8200, 68, 780);

-- -------------------------------------------------------
-- TAULA: sesiones_entrenamiento
-- Relaciona jugadors amb entrenaments (muchos a muchos)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS sesiones_entrenamiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entrenamiento_id INT NOT NULL,
    jugador_id INT NOT NULL,
    asistio TINYINT(1) DEFAULT 1,          -- 1=ha assistit, 0=no ha assistit
    puntuacion INT DEFAULT NULL,           -- Puntuació de l’entrenador (1-10)
    notas TEXT,                            -- Notes de l’entrenador
    FOREIGN KEY (entrenamiento_id) REFERENCES entrenamientos(id),
    FOREIGN KEY (jugador_id) REFERENCES usuarios(id)
);

-- Inserir relacions jugador-entrenament
INSERT INTO sesiones_entrenamiento (entrenamiento_id, jugador_id, asistio, puntuacion) VALUES
(1, 3, 1, 8), (1, 4, 1, 7), (1, 5, 1, 9),
(2, 3, 1, 9), (2, 4, 0, NULL), (2, 5, 1, 7),
(3, 3, 1, 8), (3, 4, 1, 8), (3, 5, 1, 10);